public class Pract{

    public static void main(String[] args){

    }
}


////Input: s = "hello"
////▪ Output: 2
//public class Pract {
//    public static boolean isVowel(char ch) {
//         ch = Character.toUpperCase(ch);//paramacomapre lahat, convert sa upper lahat
//        return(ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' );
//    }
//    public static int CountV(String str){
//            int count = 0; // Initialize count to 0
//            for (int i = 0; i < str.length(); i++) {
//                if (isVowel(str.charAt(i))) {
//                    ++count;
//                }
//            }
//            return count;
//        }
//    public static int Repeat(String str, char ch) {
//        int count = 0;
//        str = str.toLowerCase();  // Convert string to lower case
//        ch = Character.toLowerCase(ch);  // Convert character to lower case
//
//        for (int i = 0; i < str.length(); i++) {
//            if (str.charAt(i) == ch) {
//                ++count;
//            }
//        }
//        return count;  // Move return statement outside of the loop
//    }
//
//    public static int countLetters(String str) {
//        int count = 0;
//        for (int i = 0; i < str.length(); i++) {
//            if (Character.isLetter(str.charAt(i))) {
//                ++count;
//            }
//        }
//        return count;
//    }
//
//    public static void main(String[] args) {
//            String s = "Hello";
//            System.out.println(CountV(s));
//            System.out.println(Repeat(s, 'l'));
//            System.out.println(countLetters(s));
//        }
//    }
